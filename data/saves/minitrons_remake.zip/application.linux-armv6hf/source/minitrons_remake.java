import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import javax.swing.*; 
import javax.swing.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class minitrons_remake extends PApplet {

int screenX;
int screenY;
int mode;
int tronicsId;
int menuX;
float dt;
float mouseTime;
float zoom;
String[] MODES;
String[] TRONICS;
PImage[] TRONICSIMG;
String messageText;
String fileName;
PFont font8;
PFont font16;
ArrayList<Tronic> tronics;
ArrayList<Wire> wires;
ArrayList<QueuedWrapper> events;
ArrayList<Circle> circles;
Tronic dragTronic;
MouseWire wireStart;
MenuDisplay menu;
DataEntry dataEntry;
boolean shiftDown;
boolean ctrlDown;
boolean altDown;
boolean menuOpen;

public void setup(){
    
    surface.setResizable(true);
    font8 = loadFont("neverfont8.vlw");
    font16 = loadFont("neverfont16.vlw");
    println("Loaded.");
    screenX = 0;
    screenY = 0;
    mode = 0;
    dt = 0;
    mouseTime = 0;
    tronicsId = 0;
    menuX = 16;
    zoom = 1;
    shiftDown = false;
    ctrlDown = false;
    altDown = false;
    menuOpen = false;
    MODES = new String[]{"EDIT", "COMPUTE", "WIRE", "FILE"};
    TRONICS = new String[]{
        "data", "fdat", "and", "add", "subtract", "multi",
        "divide", "modulo", "random", "ifelse", "ifgt", "ifcontains",
        "ybutton", "bbutton", "gbutton", "rbutton", "keyboard", "monitor"
    };
    TRONICSIMG = new PImage[TRONICS.length];
    for(int i = 0; i < TRONICS.length;i++){
        TRONICSIMG[i] = loadImage("assets/icons/" + TRONICS[i] + ".png");
    }
    messageText = "NEW FILE";
    fileName = "";
    tronics = new ArrayList<Tronic>();
    wires = new ArrayList<Wire>();
    events = new ArrayList<QueuedWrapper>();
    circles = new ArrayList<Circle>();
    menu = new MenuDisplay();
    dataEntry = new DataEntry();
    dataEntry.addWindowListener(new java.awt.event.WindowListener() {
       public void windowOpened(java.awt.event.WindowEvent e) {}
       public void windowIconified(java.awt.event.WindowEvent e) {}
       public void windowDeiconified(java.awt.event.WindowEvent e) {}
       public void windowDeactivated(java.awt.event.WindowEvent e) {}
       public void windowClosing(java.awt.event.WindowEvent e) {
           dataEntry.setVisible(false);
           dataEntry.setTronic(null);
       }
       public void windowClosed(java.awt.event.WindowEvent e) {}
       public void windowActivated(java.awt.event.WindowEvent e) {}
    });
}

public void keyPressed(){
    mouseTime = 0;
    //println(keyCode);
    if(key == 'r'){
        screenX = 0;
        screenY = 0;
        zoom = 1.0f;
    }else if(key == ' '){
        mode = (mode + 1) % 2;
        if(mode != 0){
            menuOpen = false;
        }
        menu.deselectAll();
    }else if(key == 'c'){
        menu.deselectAll();
        tronics.clear();
        wires.clear();
    }else if(key == 'e' && mode == 0){
        menuOpen = !menuOpen;
    }else if(mode == 1 && (key == '1' || key == '2' || key == '3' || key == '4')){
        int type = Character.getNumericValue(key) - 1;
        for(Tronic tron: tronics){
            if(tron instanceof Button && ((Button)tron).getType() == type && sqrt(pow((tron.getX() + tron.getWidth()/2) - (mouseX/zoom + screenX), 2) + pow((tron.getY() + tron.getHeight()/2) - (mouseY/zoom + screenY), 2)) <= 150){
                ((Clickable)tron).clicked(mouseX, mouseY, zoom);
            }
        }
        int circleColor;
        switch(type){
            case 0:
            default:
                circleColor = 0xffFFD919;
                break;
            case 1:
                circleColor = 0xff088DFF;
                break;
            case 2:
                circleColor = 0xff08FF19;
                break;
            case 3:
                circleColor = 0xffFB0302;
                break;
        }
        circles.add(new Circle(circleColor, mouseX, mouseY));
    }else if((keyCode == 83 || key == 's') && ctrlDown && mode == 0){
        messageText = "SAVING...";
        mode = 3;
        menu.deselectAll();
        new SmallTextEntry(fileName, new SmallTextEntryEvent(){
            public void canceled(){
                messageText = "SAVING CANCELED.";
                mode = 0;
            }
            
            public void saved(String contents){
                if(!contents.equals("")){
                    JSONArray output = new JSONArray();
                    JSONArray tronicsOutput = new JSONArray();
                    int objs = 0;
                    HashMap<Wire, Integer[]> wireDetails = new HashMap<Wire, Integer[]>();
                    messageText = "SAVING... (TRONICS)";
                    for(Tronic tron: tronics){
                        JSONObject tronObj = new JSONObject();
                        tronObj.setString("type", tron.getClass().getSimpleName());
                        tronObj.setString("name", tron.toString());
                        tronObj.setInt("objIndex", objs);
                        tronObj.setInt("posX", tron.getX());
                        tronObj.setInt("posY", tron.getY());
                        if(tron instanceof Button){
                            tronObj.setInt("buttonType", ((Button)tron).getType());
                        }else if(tron instanceof Data){
                            tronObj.setString("dataContents", ((Data)tron).getData());
                        }else if(tron instanceof OperatorTronic){
                            tronObj.setInt("operatorType", ((OperatorTronic)tron).getType());
                        }else if(tron instanceof Monitor){
                            tronObj.setInt("monitorLineNumber", ((Monitor)tron).getTextLineNumber());
                            String[] text = ((Monitor)tron).getTextLines();
                            JSONArray textLines = new JSONArray();
                            for(int i = 0; i < text.length; i++){
                                textLines.setString(i, text[i]);
                            }
                            tronObj.setJSONArray("monitorLines", textLines);
                        }else if(tron instanceof ComparisonTronic){
                            tronObj.setInt("comparisonType", ((ComparisonTronic)tron).getType());
                        }
                        for(int n = 0; n < tron.getNodes().length; n++){
                            for(int w = 0; w < tron.getNodes()[n].getNumWires(); w++){
                                Wire wire = tron.getNodes()[n].getWire(w);
                                if(!wireDetails.containsKey(wire)){
                                    wireDetails.put(wire, new Integer[] {objs, n});
                                }else if(wireDetails.containsKey(wire)){
                                    int t1Id = wireDetails.get(wire)[0];
                                    int t1node = wireDetails.get(wire)[1];
                                    wireDetails.put(wire, new Integer[] {t1Id, t1node, objs, n, wire.getWireColor()});
                                }
                            }
                        }
                        tronicsOutput.setJSONObject(objs, tronObj);
                        objs++;
                    }
                    messageText = "SAVING... (WIRES)";
                    JSONArray wiresOutput = new JSONArray();
                    int wires = 0;
                    for(Integer[] dets: wireDetails.values()){
                        if(dets.length == 5){
                            JSONArray thisSet = new JSONArray();
                            for(int i = 0; i < dets.length; i++){
                                thisSet.setInt(i, dets[i]);
                            }
                            wiresOutput.setJSONArray(wires, thisSet);
                            wires++;
                        }else{
                            println("Invalid wire array?");
                        }
                    }
                    output.setJSONArray(0, tronicsOutput);
                    output.setJSONArray(1, wiresOutput);
                    saveJSONArray(output, "/saves/" + contents + ".json");
                    messageText = "SAVED";
                    fileName = contents;
                    mode = 0;
                }else{
                    messageText = "SAVING CANCELED";
                    mode = 0;
                }
            }
        }).showWindow();
    }else if((keyCode == 79 || key == 'o') && ctrlDown && mode == 0){
        messageText = "LOADING...";
        mode = 3;
        menu.deselectAll();
        new SmallTextEntry(fileName, "Load", new SmallTextEntryEvent(){
            public void canceled(){
                messageText = "LOADING CANCELED.";
                mode = 0;
            }
            
            public void saved(String contents){
                if(!contents.equals("")){
                    JSONArray input = null;
                    try{
                        input = loadJSONArray("/saves/" + contents + ".json");
                    }catch(Exception e){
                        messageText = "FILE DOES NOT EXIST";
                        mode = 0;
                        return;
                    }
                    JSONArray tronicsInput = input.getJSONArray(0);
                    JSONArray wiresInput = input.getJSONArray(1);
                    HashMap<Integer, Tronic> tronicDetails = new HashMap<Integer, Tronic>();
                    tronicsId = 0;
                    messageText = "LOADING... (TRONICS)";
                    for(int i = 0; i < tronicsInput.size(); i++){
                        JSONObject tronObj = tronicsInput.getJSONObject(i);
                        Tronic newTronic = null;
                        if(tronObj.getString("type").equals("Button")){
                            newTronic = new Button(tronObj.getInt("buttonType"), tronObj.getInt("posX"), tronObj.getInt("posY"), tronObj.getString("name"));
                        }else if(tronObj.getString("type").equals("Data")){
                            newTronic = new Data(tronObj.getInt("posX"), tronObj.getInt("posY"), tronObj.getString("name"));
                            ((Data)newTronic).setData(tronObj.getString("dataContents"));
                        }else if(tronObj.getString("type").equals("OperatorTronic")){
                            newTronic = new OperatorTronic(tronObj.getInt("operatorType"), tronObj.getInt("posX"), tronObj.getInt("posY"), tronObj.getString("name"));
                        }else if(tronObj.getString("type").equals("Monitor")){
                            newTronic = new Monitor(tronObj.getInt("posX"), tronObj.getInt("posY"), tronObj.getString("name"));
                            JSONArray lines = tronObj.getJSONArray("monitorLines");
                            for(int x = 0; x < tronObj.getInt("monitorLineNumber"); x++){
                                ((Monitor)newTronic).processString(lines.getString(x));
                            }
                        }else if(tronObj.getString("type").equals("Keyboard")){
                            newTronic = new Keyboard(tronObj.getInt("posX"), tronObj.getInt("posY"), tronObj.getString("name"));
                        }else if(tronObj.getString("type").equals("FDat")){
                            newTronic = new FDat(tronObj.getInt("posX"), tronObj.getInt("posY"), tronObj.getString("name"));
                        }else if(tronObj.getString("type").equals("ComparisonTronic")){
                            newTronic = new ComparisonTronic(tronObj.getInt("comparisonType"), tronObj.getInt("posX"), tronObj.getInt("posY"), tronObj.getString("name"));
                        }
                        tronics.add(newTronic);
                        tronicDetails.put(tronObj.getInt("objIndex"), newTronic);
                        tronicsId++;
                    }
                    messageText = "LOADING... (WIRES)";
                    for(int i = 0; i < wiresInput.size(); i++){
                        JSONArray thisWire = wiresInput.getJSONArray(i);
                        Tronic tron1 = tronicDetails.get(thisWire.getInt(0));
                        Tronic tron2 = tronicDetails.get(thisWire.getInt(2));
                        Wire newWire = new Wire(tron1.getNodes()[thisWire.getInt(1)],tron2.getNodes()[thisWire.getInt(3)], thisWire.getInt(4));
                        wires.add(newWire);
                        tron1.getNodes()[thisWire.getInt(1)].addWire(newWire);
                        tron2.getNodes()[thisWire.getInt(3)].addWire(newWire);
                    }
                    messageText = "LOADED";
                    fileName = contents;
                    mode = 0;
                }else{
                    messageText = "LOADING CANCELED";
                    mode = 0;
                }
            }
        }).showWindow();
    }else if(keyCode == SHIFT){
        shiftDown = true;
    }else if(keyCode == CONTROL){
        ctrlDown = true;
    }else if(keyCode == ALT){
        altDown = true;
    }
}

public void keyReleased(){
    if(keyCode == SHIFT){
        shiftDown = false;
    }else if(keyCode == CONTROL){
        ctrlDown = false;
    }else if(keyCode == ALT){
        altDown = false;
    }
}
    

public void mousePressed(){
    mouseTime = 0;
    if(menuOpen && mouseX < 200){
        int index = (mouseY / 32) * 6 + (mouseX / 32);
        if(index < TRONICS.length){
            String tronic = TRONICS[index];
            Tronic newTronic;
            tronicsId++;
            switch(tronic){
                case "data":
                    newTronic = new Data(screenX + mouseX - 24, screenY + mouseY - 24,"Data"+tronicsId);
                    break;
                case "fdat":
                    newTronic = new FDat(screenX + mouseX - 24, screenY + mouseY - 24,"FDat"+tronicsId);
                    break;
                case "ifelse":
                    newTronic = new ComparisonTronic(0, screenX + mouseX - 24, screenY + mouseY - 24,"IfElse"+tronicsId);
                    break;
                case "ifgt":
                    newTronic = new ComparisonTronic(1, screenX + mouseX - 24, screenY + mouseY - 24,"IfGT"+tronicsId);
                    break;
                case "ifcontains":
                    newTronic = new ComparisonTronic(2, screenX + mouseX - 24, screenY + mouseY - 24,"IfContains"+tronicsId);
                    break;
                case "and":
                    newTronic = new OperatorTronic(4, screenX + mouseX - 24, screenY + mouseY - 24,"And"+tronicsId);
                    break;
                case "add":
                    newTronic = new OperatorTronic(0, screenX + mouseX - 24, screenY + mouseY - 24,"Add"+tronicsId);
                    break;
                case "subtract":
                    newTronic = new OperatorTronic(1, screenX + mouseX - 24, screenY + mouseY - 24,"Sub"+tronicsId);
                    break;
                case "multi":
                    newTronic = new OperatorTronic(2, screenX + mouseX - 24, screenY + mouseY - 24,"Multi"+tronicsId);
                    break;
                case "divide":
                    newTronic = new OperatorTronic(3, screenX + mouseX - 24, screenY + mouseY - 24,"Div"+tronicsId);
                    break;
                case "random":
                    newTronic = new OperatorTronic(5, screenX + mouseX - 24, screenY + mouseY - 24,"Random"+tronicsId);
                    break;
                case "modulo":
                    newTronic = new OperatorTronic(6, screenX + mouseX - 24, screenY + mouseY - 24,"Modulo"+tronicsId);
                    break;
                case "ybutton":
                    newTronic = new Button(0, screenX + mouseX - 24, screenY + mouseY - 24,"Button"+tronicsId);
                    break;
                case "bbutton":
                    newTronic = new Button(1, screenX + mouseX - 24, screenY + mouseY - 24,"Button"+tronicsId);
                    break;
                case "gbutton":
                    newTronic = new Button(2, screenX + mouseX - 24, screenY + mouseY - 24,"Button"+tronicsId);
                    break;
                case "rbutton":
                    newTronic = new Button(3, screenX + mouseX - 24, screenY + mouseY - 24,"Button"+tronicsId);
                    break;
                case "keyboard":
                    newTronic = new Keyboard(screenX + mouseX - 48, screenY + mouseY - 24, "Keboard"+tronicsId);
                    break;
                case "monitor":
                    newTronic = new Monitor(screenX + mouseX - 128, screenY + mouseY - 112,"Monitor"+tronicsId);
                    break;
                default:
                    newTronic = new Data(screenX + mouseX - 24, screenY + mouseY - 24,"Data"+tronicsId);
                    break;
            }
            menu.deselectAll();
            dragTronic = newTronic;
            menuOpen = false;
            tronics.add(newTronic);
            return;
        }
    }
    if(mouseButton == LEFT && mode == 0){
        if(menu.getSelected().size() > 0){
            int mouseIndex = menu.containsPoint(mouseX, mouseY, screenX, screenY, zoom);
            MenuDisplay.MenuItem[] items = menu.getItems();
            if(!altDown && mouseIndex >= 0 && items.length > mouseIndex){
                String action = items[mouseIndex].getAction();
                if(action == "DESELECT"){
                    menu.deselectAll();
                    return;
                }else if(action == "MOVE"){
                    dragTronic = menu.getSelected().get(0);
                    return;
                }else if(action == "DELETE"){
                    for(Tronic tron: menu.getSelected()){
                        if(dataEntry.getTronic() == tron){
                            dataEntry.setTronic(null);
                        }
                        for(Node node: tron.getNodes()){
                            while(node.getNumWires() > 0){
                                wires.remove(node.getWire(0));
                                node.getWire(0).deleteWire();
                            }
                        }
                        tronics.remove(tron);
                    }
                    menu.deselectAll();
                }else if(action == "DECOUPLE"){
                    for(Wire wire: menu.getWires()){
                        wire.deleteWire();
                        wires.remove(wire);
                    }
                }else if(action == "DATAENTRY"){
                    if(menu.getSelected().get(0) instanceof Data){
                        dataEntry.setTronic((Data)menu.getSelected().get(0));
                        dataEntry.showWindow();
                    }
                }else if(action == "RENAME"){
                    String ref = "";
                    if(menu.getSelected().size() == 1){
                        ref = menu.getSelected().get(0).toString();
                    }
                    new SmallTextEntry(ref,new SmallTextEntryEvent(){
                        public void canceled(){
                            //sucks to suck
                            menu.deselectAll();
                        }
                        
                        public void saved(String contents){
                            if(!contents.equals("")){
                                for(Tronic tron: menu.getSelected()){
                                    tron.setName(contents);
                                }
                                menu.deselectAll();
                            }
                        }
                    }).showWindow();
                    return;
                }
            }
        }
        for(Tronic tron: tronics){
            for(Node node: tron.getNodes()){
                if(node.containsPoint(screenX + (int)(mouseX / zoom), screenY + (int)(mouseY / zoom), tron.getX(), tron.getY())){
                    mode = 2;
                    wireStart = new MouseWire(node, node.getNodeColor());
                    return;
                }
            }
            if(tron.containsPoint(screenX + (int)(mouseX / zoom), screenY + (int)(mouseY / zoom))){
                if(ctrlDown){
                    if(!menu.contains(tron)){
                        menu.deselectAll();
                    }
                    dragTronic = tron;
                }else if(shiftDown){
                    menu.toggle(tron);
                }else{
                    menu.deselectAll();
                    menu.toggle(tron);
                }
                return;
            }
        }
        menu.deselectAll(); //deselect if they clicked nothing
    }else if(mode == 1){
        for(Tronic tron: tronics){
            if(tron instanceof Clickable){
                if(tron.containsPoint(screenX + (int)(mouseX / zoom), screenY + (int)(mouseY / zoom))){
                    ((Clickable) tron).clicked(mouseX, mouseY, zoom);
                }
            }else if(tron instanceof Data){
                if(tron.containsPoint(screenX + (int)(mouseX / zoom), screenY + (int)(mouseY / zoom))){
                    println("Data: " + ((Data) tron).getData());
                }
            }
        }
    }else if(mode == 2 && wireStart != null){
        //wire time...
        for(Tronic tron: tronics){
            for(Node node: tron.getNodes()){
                if(node.containsPoint(screenX + (int)(mouseX / zoom), screenY + (int)(mouseY / zoom), tron.getX(), tron.getY())){
                    //make a wire connecting two nodes
                    if(wireStart.canConnectTo(node)){
                        int wireColor = 0xffFF0000;
                        if(wireStart.getFirstPoint().getType() == 3 || node.getType() == 3){
                            wireColor = 0xffFF0000;
                        }else if(wireStart.getFirstPoint().getType() == 0 || node.getType() == 0){
                            wireColor = 0xff0000FF;
                        }else if(wireStart.getFirstPoint().getType() == 1 || node.getType() == 1){
                            wireColor = 0xff00FF00;
                        }
                        Wire newWire = new Wire(wireStart.getFirstPoint(), node, wireColor);
                        wires.add(newWire);
                        wireStart.getFirstPoint().addWire(newWire);
                        node.addWire(newWire);
                        menu.selectWires();
                    }
                    mode = 0;
                    return;
                }
            }
        }
        mode = 0;
    }
}

public void mouseWheel(MouseEvent evt){
    float oldZoom = zoom;
    zoom = max(min(2.0f, zoom * abs(pow(2.0f,-evt.getCount()))),0.5f);
    if(zoom != oldZoom){
        screenX = (int) (mouseX - (width / 2) / zoom);
        screenY = (int) (mouseY - (height / 2) / zoom);
    }
}

public void mouseReleased(){
    if(dragTronic != null){
        menu.calculatePosition();
        dragTronic = null;
    }
}

public void addEvent(QueuedEvent evt){
    events.add(new QueuedWrapper(evt));
}

public void startFlow(Node outNode, Tronic startingTronic, FlowDetails flow){
    if(outNode.getNumWires() > 0){
        startingTronic.setDisabled();
        Wire nextWire = outNode.getWire(0);
        nextWire.addPending();
        addEvent((new QueuedEvent(){
            Node thisNode;
            Wire thisWire;
            Tronic startingTronic;
            FlowDetails thisDetails;
            
            public QueuedEvent setNextDetails(Node thisNode, Wire thisWire, Tronic startingTronic, FlowDetails thisDetails){
                this.thisNode = thisNode;
                this.thisWire = thisWire;
                this.startingTronic = startingTronic;
                this.thisDetails = thisDetails;
                return this;
            }
            
            public double getDelay(){
                return 0.25f;
            }
            
            public void invoke(){
                thisWire.subPending();
                Tronic nextTronic = thisWire.getOtherNode(thisNode).getParent();
                Node nextNode;
                if(nextTronic instanceof InFlow){
                    nextNode = ((InFlow) nextTronic).getFlow(thisDetails);
                    if(nextNode != null){
                        println("Sending flow: " + nextNode.getParent() + " S: " + startingTronic);
                        startFlow(nextNode, startingTronic, thisDetails);
                    }else{
                        println("Ending flow");
                        startingTronic.setEnabled();
                    }
                }else{
                    println("Ending flow");
                    startingTronic.setEnabled();
                }
            }
        }).setNextDetails(outNode, nextWire, startingTronic, flow));
    }else{
        println("Ending flow");
        startingTronic.setEnabled();
    }
}

public void draw(){
    dt += (1.0f/frameRate) % 2.5f;
    background(0xffE5E5E5);
    if(mousePressed && mouseButton == RIGHT){
        screenX += (pmouseX - mouseX) / zoom;
        screenY += (pmouseY - mouseY) / zoom;
    }
    if(dragTronic != null){
        for(Tronic tron: menu.getSelected()){
            if(tron != dragTronic){
                int relX = tron.getX() - dragTronic.getX();
                int relY = tron.getY() - dragTronic.getY();
                tron.moveTronic((int)((screenX + (mouseX) / zoom - dragTronic.getWidth() / 2) - (screenX + (mouseX) / zoom - dragTronic.getWidth() / 2) % 8) + relX, (int)((screenY + (mouseY) / zoom - dragTronic.getHeight() / 2) - (screenY + (mouseY) / zoom - dragTronic.getHeight() / 2) % 8) + relY);
            }
        }
        dragTronic.moveTronic((int)((screenX + (mouseX) / zoom - dragTronic.getWidth() / 2) - (screenX + (mouseX) / zoom - dragTronic.getWidth() / 2) % 8), (int)((screenY + (mouseY) / zoom - dragTronic.getHeight() / 2) - (screenY + (mouseY) / zoom - dragTronic.getHeight() / 2) % 8));
    }
    menu.renderHighlights(dt, screenX, screenY, zoom);
    fill(0xffFF0000);
    strokeWeight(0);
    if(dataEntry.getTronic() != null){
        rect(dataEntry.getTronic().getX() - 2 - screenX, dataEntry.getTronic().getY() - 2 - screenY, dataEntry.getTronic().getWidth() + 4, dataEntry.getTronic().getHeight() + 4);
    }
    fill(0xff000000);
    stroke(0xff000000);
    strokeWeight(1);
    for(int x = (int) ((-screenX % 16) * zoom); x < width; x += (16 * zoom)){
        line(x,0,x,height);
    }
    for(int y = (int) ((-screenY % 16) * zoom); y < height; y += (16 * zoom)){
        line(0, y, width, y);
    }
    
    pushMatrix();
    scale(zoom);
    
    for(int c = 0; c < circles.size(); c++){
        if(!circles.get(c).render(zoom)){
            circles.remove(c);
            c--;
        }
    }
    
    strokeWeight(6);
    for(Wire wire: wires){
        wire.render(screenX, screenY, (wire.getActivated() ? 0xffFFFFFF : wire.getWireColor()));
    }
    if(mode == 2 && wireStart != null){
        wireStart.render((int) (mouseX / zoom), (int)(mouseY / zoom), screenX, screenY);
    }
    pushMatrix();
    if(zoom == 1.0f){
        textFont(font8, 16);
    }else{
        textFont(font16, 16);
    }
    scale(.5f);
    for(int i = tronics.size() - 1; i >= 0; i--){
        tronics.get(i).renderTronic(screenX, screenY);
        pushMatrix();
        scale(2);
        tronics.get(i).renderNodes(mouseX, mouseY, screenX, screenY, zoom, (mode != 1));
        popMatrix();
    }
    textFont(font8, 8);
    popMatrix();
    
    popMatrix();
    
    if(mode == 0 && dragTronic == null && !altDown){
        menu.renderMenu(screenX, screenY, mouseX, mouseY, zoom);
    }
    
    for(int i = 0; i < events.size(); i++){
        if(events.get(i).tick(1.0f / frameRate)){
            events.remove(i);
            i--;
        }
    }
    if(pmouseX == mouseX && pmouseY == mouseY){
        if(mouseTime < .5f){
            mouseTime += (1.0f/frameRate);
        }
    }else{
        mouseTime = 0;
    }
    if(mouseTime > .5f){
        for(Tronic tron: tronics){
            if(tron.containsPoint(screenX + (int)(mouseX / zoom), screenY + (int)(mouseY / zoom))){
                noStroke();
                fill(0xffFFFFFF, 200);
                rect(mouseX + 10, mouseY - 10, textWidth("Name: " + tron) + 4, 12);
                fill(0xff000000);
                text("Name: " + tron, mouseX + 13, mouseY);
                break;
            }
        }
    }
    
    stroke(0xff404040);
    strokeWeight(1);
    
    fill(0xff606060);
    rect(0,height - 16, width - 1, 16);
    if(menuOpen){
        menuX = min(menuX + 20, 200);
    }else{
        menuX = max(menuX - 20, 8);
    }
    rect(0, 0, menuX, height - 16);
    for(int i = 0; i < TRONICS.length; i++){
        if(TRONICSIMG[i] != null){
            image(TRONICSIMG[i], (-188 + menuX) + (i % 6) * 32, 16 + 32 * (i / 6));
        }
    }
    fill(0xffFFFFFF);
    text((menuOpen ? "<\n<\n<" : ">\n>\n>"),-8 + menuX,height / 2 - 16);
    text("(" + screenX + ", " + screenY + ")", 4, height - 4); 
    text("MODE: " + MODES[mode] + "", 204, height - 4);
    text("TOTAL: " + tronics.size() + "", 404, height - 4);
    text(messageText, 604, height - 4);
}
class Button extends Tronic implements Clickable{
    int type;
    PImage sprite;
    boolean cooldown;
    
    Node outNode;
    
    public Button(int x, int y, String name){
        this(0, x, y, name);
    }
    
    public Button(int type, int x, int y, String name){
        super(x, y, 48, 48, name);
        this.type = type;
        switch(type){
            case 0:
                sprite = loadImage("assets/ybutton.png");
                break;
            case 1:
                sprite = loadImage("assets/bbutton.png");
                break;
            case 2:
                sprite = loadImage("assets/gbutton.png");
                break;
            case 3:
                sprite = loadImage("assets/rbutton.png");
                break;
            default:
                sprite = loadImage("assets/ybutton.png");
                break;
        }
        cooldown = false;
        outNode = new Node(this, 3, 48, 21, 1, 0);
    }
    
    public void clicked(int x, int y, float zoom){
        if(!cooldown){
            cooldown = true;
            sendFlow();
            addEvent(new QueuedEvent(){
                public double getDelay(){
                    return 0.5f;
                }
                public void invoke(){
                    cooldown = false;
                }
            });
        }
    }
    
    public void sendFlow(){
        if(isEnabled()){
            startFlow(outNode, this, new FlowDetails());
        }
    }
    
    
    public int getType(){
        return type;
    }
    public void renderTronic(int screenX, int screenY){
        image(sprite, (getX() - screenX) * 2, (getY() - screenY) * 2);
    }
    
    public void renderNodes(int mouseX, int mouseY, int screenX, int screenY, float zoom, boolean highlight){
        outNode.render(mouseX, mouseY, screenX, screenY, getX(), getY(), zoom, highlight);
    }
    
    public Node[] getNodes(){
        return new Node[]{outNode};
    }
}
        
class Circle{
    int thisColor;
    float x;
    float y;
    float transparency;
    
    Circle(int val, int x, int y){
        this.thisColor = val;
        this.transparency = 100;
        this.x = x;
        this.y = y;
    }
    
    public boolean render(float zoom){
        transparency -= 5;
        pushStyle();
        stroke(thisColor);
        fill(thisColor, transparency);
        ellipse(x/zoom, y/zoom, 300, 300);
        popStyle();
        return transparency > 0;
    }
}
interface Clickable{
    public void clicked(int x, int y, float zoom);
}
class ComparisonTronic extends Tronic implements InFlow{
    PImage sprite;
    int type;
    InFlow nextTronic;
    
    Node inNode;
    Node aNode;
    Node bNode;
    Node trueNode;
    Node falseNode;
    
    public ComparisonTronic(int x, int y, String name){
        this(0, x, y, name);
    }
    
    public ComparisonTronic(int type, int x, int y, String name){
        super(x, y, 48, 48, name);
        this.type = type;
        switch(type){
            case 0:
                sprite = loadImage("assets/ifequals.png");
                break;
            case 1:
                sprite = loadImage("assets/ifgt.png");
                break;
            case 2:
                sprite = loadImage("assets/ifcontains.png");
                break;
            default:
                sprite = loadImage("assets/ifequals.png");
                break;
        }
        inNode = new Node(this, 2, -6, 21, -1, 0);
        aNode = new Node(this, 1, 21, -6, 0, -1);
        bNode = new Node(this, 1, 21, 48, 0, 1);
        trueNode = new Node(this, 3, 48, 30, 1, 0);
        falseNode = new Node(this, 3, 48, 12, 1, 0);
    }
    
    public Node getFlow(FlowDetails flow){
        switch(type){
            case 0:
                if(flow.getData(aNode).equals(flow.getData(bNode))){
                    return trueNode;
                }else{
                    return falseNode;
                }
            case 1:
                String a,b;
                double numA, numB;
                a = flow.getData(aNode);
                if(a.equals("")){
                    numA = 0;
                }else{
                    try{
                        numA = Double.valueOf(a);
                    }catch(NumberFormatException e){
                        numA = 0;
                    }
                }
                b = flow.getData(bNode);
                if(b.equals("")){
                    numB = 0;
                }else{
                    try{
                        numB = Double.valueOf(b);
                    }catch(NumberFormatException e){
                        numB = 0;
                    }
                }
                if(numA > numB){
                    return trueNode;
                }else{
                    return falseNode;
                }
            case 2:
                if(flow.getData(aNode).contains(flow.getData(bNode))){
                    return trueNode;
                }else{
                    return falseNode;
                }
            default:
                return falseNode;
        }
    }
    
    public int getType(){
        return type;
    }
    
    public void renderTronic(int screenX, int screenY){
        image(sprite, (getX() - screenX) * 2, (getY() - screenY) * 2);
    }
    
    public void renderNodes(int mouseX, int mouseY, int screenX, int screenY, float zoom, boolean highlight){
        inNode.render(mouseX, mouseY, screenX, screenY, getX(), getY(), zoom, highlight);
        aNode.render(mouseX, mouseY, screenX, screenY, getX(), getY(), zoom, highlight);
        bNode.render(mouseX, mouseY, screenX, screenY, getX(), getY(), zoom, highlight);
        trueNode.render(mouseX, mouseY, screenX, screenY, getX(), getY(), zoom, highlight);
        falseNode.render(mouseX, mouseY, screenX, screenY, getX(), getY(), zoom, highlight);
    }
    
    public Node[] getNodes(){
        return new Node[]{inNode, aNode, bNode, trueNode, falseNode};
    }
}
class Data extends Tronic{
    PImage sprite;
    String data;
    
    Node dataNode;
    
    public Data(int x, int y, String name){
        super(x, y, 48, 48, name);
        data = "";
        sprite = loadImage("assets/data.png");
        dataNode = new Node(this, 4, 48, 21, 1, 0);
    }
    
    public void renderTronic(int screenX, int screenY){
        image(sprite, (getX() - screenX) * 2, (getY() - screenY) * 2);
    }
    
    public void renderNodes(int mouseX, int mouseY, int screenX, int screenY, float zoom, boolean highlight){
        dataNode.render(mouseX, mouseY, screenX, screenY, getX(), getY(), zoom, highlight);
    }
    
    public void setData(String data){
        this.data = data;
    }
    
    public String getData(){
        return data;
    }
    
    public Node[] getNodes(){
        return new Node[]{dataNode};
    }
}


class DataEntry extends JFrame{
    Data tronic;
    JTextArea textArea;
    JPopupMenu popup;
    java.awt.Font psn;
    
    public DataEntry(){
        super("Data Entry");
        setAlwaysOnTop(true);
        try {
            psn = (java.awt.Font.createFont(java.awt.Font.TRUETYPE_FONT, new java.io.File(dataPath("neverfont.ttf")))).deriveFont(8f);
        } catch (Exception e) {
            psn = new java.awt.Font("Consolas", java.awt.Font.PLAIN, 12);
            e.printStackTrace();
        };
        try{
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }catch(Exception e){
            //whatever jeez....
        };
        textArea = new JTextArea();
        textArea.setFont(psn);
        textArea.setEditable(true);
        textArea.setEnabled(true);
        textArea.setBackground(java.awt.Color.BLACK);
        textArea.setForeground(java.awt.Color.GREEN);
        textArea.setCaretColor(java.awt.Color.GREEN);
        
        popup = new JPopupMenu();
        JMenuItem cutItem = new JMenuItem("Cut");
        cutItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                textArea.cut();
            }
        });
        JMenuItem copyItem = new JMenuItem("Copy");
        copyItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                textArea.copy();
            }
        });
        JMenuItem pasteItem = new JMenuItem("Paste");
        pasteItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                textArea.paste();
            }
        });
        JMenuItem selectItem = new JMenuItem("Select All");
        selectItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                textArea.selectAll();
            }
        });
        popup.add(cutItem);
        popup.add(copyItem);
        popup.add(pasteItem);
        popup.addSeparator();
        popup.add(selectItem);
        
        textArea.addMouseListener(new java.awt.event.MouseListener() {
            public void mouseReleased(java.awt.event.MouseEvent arg0) {
                if(arg0.isPopupTrigger()){
                    popup.show(textArea, arg0.getX(), arg0.getY());
                }
            }
            public void mousePressed(java.awt.event.MouseEvent arg0) {}
            public void mouseExited(java.awt.event.MouseEvent arg0) {}
            public void mouseEntered(java.awt.event.MouseEvent arg0) {}
            public void mouseClicked(java.awt.event.MouseEvent arg0) {}
        });
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        JButton getData = new JButton("Get Data");
        JButton setData = new JButton("Set Data");
        JButton clearData = new JButton("Clear");
        
        getData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                if(tronic != null){
                    textArea.setText(tronic.getData());
                }
            }
        });
        setData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                if(tronic != null){
                    tronic.setData(textArea.getText());
                }
            }
        });
        clearData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                textArea.setText("");
            }
        });
        
        GroupLayout layout = new GroupLayout(getContentPane());
        layout.setHorizontalGroup(
            layout.createParallelGroup()
            .addGroup(layout.createSequentialGroup()
                .addComponent(getData, 100, 100, 100)
                .addComponent(setData, 100, 100, 100)
                .addComponent(clearData, 100, 100, 100)
                )
            .addComponent(scrollPane)
        );
        layout.setVerticalGroup(
            layout.createSequentialGroup()
            .addGroup(layout.createParallelGroup()
                .addComponent(getData, 20, 20, 20)
                .addComponent(setData, 20, 20, 20)
                .addComponent(clearData, 20, 20, 20)
            )
            .addComponent(scrollPane)
        );
        getContentPane().setLayout(layout);
        
        pack();
        setSize(500, 600);
    }
    
    public void showWindow(){
        setVisible(true);
        toFront();
        textArea.grabFocus();
    }
    
    public void setTronic(Data tronic){
        this.tronic = tronic;
        if(tronic != null){
            setTitle("Data Entry: " + tronic);
        }else{
            setTitle("Data Entry: Disconnected");
        }
    }
    
    public Data getTronic(){
        return tronic;
    }
}
class FDat extends Tronic{
    PImage sprite;
    String data;
    
    Node dataNode;
    
    public FDat(int x, int y, String name){
        super(x, y, 48, 48, name);
        sprite = loadImage("assets/fdat.png");
        dataNode = new Node(this, 4, 48, 21, 1, 0);
    }
    
    public void renderTronic(int screenX, int screenY){
        image(sprite, (getX() - screenX) * 2, (getY() - screenY) * 2);
    }
    
    public void renderNodes(int mouseX, int mouseY, int screenX, int screenY, float zoom, boolean highlight){
        dataNode.render(mouseX, mouseY, screenX, screenY, getX(), getY(), zoom, highlight);
    }
    
    public Node[] getNodes(){
        return new Node[]{dataNode};
    }
}
public class FlowDetails{
    HashMap<FDat, String> fdats;
    
    public FlowDetails(){
        fdats = new HashMap<FDat, String>();
    }
    
    public String getData(Node dataNode){
        if(dataNode.getNumWires() > 0 && dataNode.getType() == 1){
            Tronic dataTronic = dataNode.getWire(0).getOtherNode(dataNode).getParent();
            if(dataTronic instanceof Data){
                return ((Data)dataTronic).getData();
            }else if(dataTronic instanceof FDat){
                if(fdats.containsKey((FDat)dataTronic)){
                    return fdats.get((FDat)dataTronic);
                }
            }
        }
        return "";
    }
    
    public void setData(Node dataNode, String data){
        if(dataNode.getNumWires() > 0 && dataNode.getType() == 0){
            for(int i = 0; i < dataNode.getNumWires(); i++){
                Tronic dataTronic = dataNode.getWire(i).getOtherNode(dataNode).getParent();
                if(dataTronic instanceof Data){
                    ((Data)dataTronic).setData(data);
                }else if(dataTronic instanceof FDat){
                    fdats.put((FDat)dataTronic, data);
                }
            }
        }
    }
}
interface InFlow{
    public Node getFlow(FlowDetails flow);
}
class Keyboard extends Tronic implements Clickable{
    PImage sprite;
    String memory;
    Node outNode;
    Node dataNode;
    SmallTextEntry ste;
    
    public Keyboard(int x, int y, String name){
        super(x, y, 96, 48, name);
        sprite = loadImage("assets/keyboard.png");
        outNode = new Node(this, 3, 54, -6, 0, -1);
        dataNode = new Node(this, 0, 70, -6, 0 ,-1);
        memory = "";
    }
    
    public void clicked(int x, int y, float zoom){
        if(ste == null){
            ste = new SmallTextEntry(memory, "Send", (new SmallTextEntryEvent(){
                Tronic thisTronic;
                
                public SmallTextEntryEvent setTronic(Tronic thisTronic){
                    this.thisTronic = thisTronic;
                    return this;
                }
                
                public void canceled(){
                    ste = null;
                }
                public void saved(String contents){
                    if(isEnabled()){
                        FlowDetails newFlow = new FlowDetails();
                        newFlow.setData(dataNode, contents);
                        startFlow(outNode, thisTronic, newFlow);
                    }
                    ste = null;
                }
            }).setTronic(this));
        }
        ste.showWindow();
    }
    
    public void renderTronic(int screenX, int screenY){
        image(sprite, (getX() - screenX) * 2, (getY() - screenY) * 2);
    }
    
    public void renderNodes(int mouseX, int mouseY, int screenX, int screenY, float zoom, boolean highlight){
        outNode.render(mouseX, mouseY, screenX, screenY, getX(), getY(), zoom, highlight);
        dataNode.render(mouseX, mouseY, screenX, screenY, getX(), getY(), zoom, highlight);
    }
    
    public Node[] getNodes(){
        return new Node[]{outNode, dataNode};
    }
}
class MenuDisplay{
    int x;
    int y;
    ArrayList<Tronic> tronics;
    ArrayList<Wire> wires;
    MenuItem[] items;
    
    final int OFFSET = 16;
    final int WIDTH = 125;
    final int HEIGHT = 16;
    
    public MenuDisplay(){
        x = 0;
        y = 0;
        tronics = new ArrayList<Tronic>();
        wires = new ArrayList<Wire>();
        items = new MenuItem[0];
    }
    
    public void calculatePosition(){
        if(tronics.size() == 0){
            return;
        }
        x = 0;
        y = 0;
        for(Tronic tron: tronics){
            x += tron.getX() + tron.getWidth() / 2;
            y += tron.getY() + tron.getHeight() / 2;
        }
        x /= tronics.size();
        y /= tronics.size();
    }
    
    public void selectWires(){
        wires.clear();
        for(Tronic tron: tronics){
            for(Node node: tron.getNodes()){
                for(int i = 0; i < node.getNumWires(); i++){
                    if(!wires.contains(node.getWire(i)) && tronics.contains(node.getWire(i).getOtherNode(node).getParent())){
                        wires.add(node.getWire(i));
                    }
                }
            }
        }
    }
    
    public void selectMenuItems(){
        if(tronics.size() == 0){
            items = new MenuItem[0];
        }else if(tronics.size() == 1){
            items = new MenuItem[]{
                new MenuItem(0, " -   Deselect", 0xffFF0000, "DESELECT"),
                new MenuItem(1, " \u2020   Pick Up", 0xff0000FF, "MOVE"),
                new MenuItem(2, " X   Delete", color(255, 0 ,76), "DELETE"),
                new MenuItem(3, " \u0153   Rename", 0xff00FF00, "RENAME"),
                new MenuItem(4, " \u00bb   Data Entry", 0xff00FF00, "DATAENTRY")
            };
        }else if(tronics.size() > 1){
            items = new MenuItem[]{
                new MenuItem(0, " -   Deselect", 0xffFF0000, "DESELECT"),
                new MenuItem(1, " \u2020   Pick Up", 0xff0000FF, "MOVE"),
                new MenuItem(2, " X   Delete", color(255, 0 ,76), "DELETE"),
                new MenuItem(3, " \u0153   Rename", 0xff00FF00, "RENAME"),
                new MenuItem(4, " #   Decouple", 0xff00FF00, "DECOUPLE")
            };
        }   
    }
    
    public void select(Tronic tron){
        if(!tronics.contains(tron)){
            tronics.add(tron);
        }
        selectWires();
        calculatePosition();
        selectMenuItems();
    }
    
    public void deselect(Tronic tron){
        if(tronics.contains(tron)){
            tronics.remove(tron);
        }
        selectWires();
        calculatePosition();
        selectMenuItems();
    }
    
    public void toggle(Tronic tron){
        if(tronics.contains(tron)){
            tronics.remove(tron);
        }else{
            tronics.add(tron);
        }
        selectWires();
        calculatePosition();
        selectMenuItems();
    }
    
    public boolean contains(Tronic tron){
        return tronics.contains(tron);
    }
    
    public void deselectAll(){
        tronics.clear();
        wires.clear();
    }
    
    public ArrayList<Tronic> getSelected(){
        return tronics;
    }
    
    public ArrayList<Wire> getWires(){
        return wires;
    }
    
    public MenuItem[] getItems(){
        return items;
    }
    
    public int containsPoint(int x, int y, int screenX, int screenY, float zoom){
        if(x > (this.x * zoom) + OFFSET - (screenX * zoom) && x < (this.x * zoom) + OFFSET + WIDTH - (screenX * zoom) && y > (this.y * zoom) + OFFSET - (screenY * zoom)){
            return (int) (y - (this.y * zoom + OFFSET - screenY * zoom)) / 17;
        }
        return -1;
    }
    
    public void renderHighlights(float dt, int screenX, int screenY, float zoom){
        if(tronics.size() > 0){
            pushMatrix();
            scale(zoom);
            noStroke();
            fill(color(255, (int) (sin(TWO_PI * dt / 2.5f) * 15) + 215, (int) (sin(TWO_PI * dt / 2.5f) * 60) + 80));
            for(Tronic tron: tronics){
                rect(tron.getX() - 6 - screenX, tron.getY() - 6 - screenY, tron.getWidth() + 12, tron.getHeight() + 12);
            }
            strokeWeight(12);
            for(Wire wire: wires){
                wire.render(screenX, screenY, color(255, (int) (sin(TWO_PI * dt / 2.5f) * 15) + 215, (int) (sin(TWO_PI * dt / 2.5f) * 60) + 80));
            }
            popMatrix();
        }
    }
    
    public void renderMenu(int screenX, int screenY, int mouseX, int mouseY, float zoom){
        if(tronics.size() > 0){
            strokeWeight(1);
            int mousePoint = containsPoint(mouseX, mouseY, screenX, screenY, zoom);
            for(MenuItem item: items){
                item.render((int) (x * zoom), (int) (y * zoom), (int) (screenX * zoom), (int) (screenY * zoom), mousePoint);
            }
        }
    }
    
    class MenuItem{
        int index;
        String title;
        int itemColor;
        String action;
        
        public MenuItem(int index, String title, int itemColor, String action){
            this.index = index;
            this.title = title;
            this.itemColor = itemColor;
            this.action = action;
        }
        
        public void render(int menuX, int menuY, int screenX, int screenY, int mouseIndex){
            if(mouseIndex == index){
                fill(itemColor);
            }else{
                fill(color(40,40,40,160));
            }
            stroke(itemColor);
            rect(menuX + OFFSET - screenX, menuY + OFFSET + (17 * index) - screenY, WIDTH, HEIGHT);
            fill(0xffFFFFFF);
            text(title, menuX + OFFSET - screenX, menuY + OFFSET + (17 * index) + 12 - screenY);
        }
        
        public String getAction(){
            return action;
        }
        
    }
}
class Monitor extends Tronic implements InFlow{
    String[] text;
    int lines;
    PImage sprite;
    Node inNode;
    Node outNode;
    Node dataNode;
    //N8: 17 rows
    //mt: 30 rows
    //N8: 30 columns
    //mt: 21 columns

    public Monitor(int x, int y, String name){
        super(x, y, 256, 224, name);
        sprite = loadImage("assets/monitor.png");
        inNode = new Node(this, 2, 113, 218, -1, 0);
        outNode = new Node(this, 3, 137, 218, 1, 0);
        dataNode = new Node(this, 1, 125, 224, 0, 1);
        text = new String[22];
        for(int i = 0; i < text.length; i++){
            text[i] = "";
        }
        lines = 0;
    }
    
    public void addLine(){
        lines++;
        if(lines >= text.length){
            for(int i = 1; i < text.length; i++){
                text[i - 1] = text[i];
            }
            lines = text.length - 1;
            text[lines] = "";
        }
    }
    
    public void processString(String input){
        for(String bit: input.split("\n|(/n)")){
            String tempBit = new String(bit);
            while(tempBit.length() >= 31){
                text[lines] += tempBit.substring(0, 30);
                tempBit = tempBit.substring(30);
                addLine();
            }
            text[lines] += tempBit + " ";
            addLine();
        }
    }
        
    
    public Node getFlow(FlowDetails flow){
        String result = flow.getData(dataNode);
        if(result.length() > (30 * 21)){
            result = result.substring(result.length() - (21 * 21));
        }
        processString(result);
        return outNode;
    }
    
    public String[] getTextLines(){
        return text;
    }
    
    public int getTextLineNumber(){
        return lines;
    }
    
    public void renderTronic(int screenX, int screenY){
        image(sprite, (getX() - screenX) * 2, (getY() - screenY) * 2);
        fill(0xffFFFFFF);
        for(int i = 0; i < lines; i++){
            text(text[i], (9 + getX() - screenX) * 2, (12 + i * 10 + getY() - screenY) * 2);
        }
    }
    
    public void renderNodes(int mouseX, int mouseY, int screenX, int screenY, float zoom, boolean highlight){
        inNode.render(mouseX, mouseY, screenX, screenY, getX(), getY(), zoom, highlight);
        outNode.render(mouseX, mouseY, screenX, screenY, getX(), getY(), zoom, highlight);
        dataNode.render(mouseX, mouseY, screenX, screenY, getX(), getY(), zoom, highlight);
    }
    
    public Node[] getNodes(){
        return new Node[]{inNode, outNode, dataNode};
    }
}
   
   
class MouseWire{
    Node firstPoint;
    Tronic firstTronic;
    int wireColor;
    
    public MouseWire(Node firstPoint, int wireColor){
        this.firstPoint = firstPoint;
        this.firstTronic = firstPoint.getParent();
        this.wireColor = wireColor;
    }
    
    public void render(int mouseX, int mouseY, int screenX, int screenY){
        stroke(wireColor);
        strokeWeight(6);
        strokeCap(SQUARE);
        noFill();
        int tronicX = firstTronic.getX() - screenX;
        int tronicY = firstTronic.getY() - screenY;
        int pointX = firstPoint.getX() + 3;
        int pointY = firstPoint.getY() + 3;
        int distance = (int) sqrt(pow((tronicX + pointX) - mouseX,2) + pow((tronicY + pointY) - mouseY,2)) / 2; 
        int dirX = firstPoint.getDirX() * distance;
        int dirY = firstPoint.getDirY() * distance;
        bezier(tronicX + pointX, tronicY + pointY, tronicX + pointX + dirX, tronicY + pointY + dirY, mouseX - dirX + 3, mouseY - dirY + 3, mouseX + 3, mouseY + 3);
    }
    
    public boolean canConnectTo(Node nextPoint){
        int type1 = firstPoint.getType();
        int type2 = nextPoint.getType();
        if(type1 == 3 && type2 == 2){ //flowout -> flowin
            return firstPoint.getNumWires() == 0;
        }else if(type1 == 2 && type2 == 3){ //flowin -> flowout
            return nextPoint.getNumWires() == 0;
        }else if(type1 == 0 && type2 == 4){ //dataout -> data
            for(int i = 0; i < firstPoint.getNumWires(); i++){
                if(firstPoint.getWire(i).getOtherNode(firstPoint) == nextPoint){
                    return false; //maybe... not so infinite
                }
            }
            return true; //infinite wires!!!!!!!!!! :-)
        }else if(type1 == 4 && type2 == 0){ //data -> dataout
            for(int i = 0; i < nextPoint.getNumWires(); i++){
                if(nextPoint.getWire(i).getOtherNode(nextPoint) == firstPoint){
                    return false;
                }
            }
            return true;
        }else if(type1 == 1 && type2 == 4){ //datain -> data
            return firstPoint.getNumWires() == 0;
        }else if(type1 == 4 && type2 == 1){ //data -> datain
            return nextPoint.getNumWires() == 0;
        }
        return false; //yeah!!! FUCK 'EM!!!
    }
    
    public Node getFirstPoint(){
        return firstPoint;
    }
}
class Node{
    int x;
    int y;
    int dirX;
    int dirY;
    int nodeColor;
    final int WIDTH = 6;
    final int HEIGHT = 6;
    int type;
    Tronic parent;
    ArrayList<Wire> wires;
    //0: Data out
    //1: Data in
    //2: Flow in
    //3: Flow out
    
    public Node(Tronic parent, int x, int y, int dirX, int dirY){
        this(parent, 0, x, y, dirX, dirY);
    }
    
    public Node(Tronic parent, int type, int x, int y, int dirX, int dirY){
        this.parent = parent;
        this.type = type;
        this.x = x;
        this.y = y;
        this.dirX = dirX;
        this.dirY = dirY;
        switch(type){
            case 0:
                nodeColor = color(18, 14, 253);
                break;
            case 1:
                nodeColor = color(67, 251, 29);
                break;
            case 2:
                nodeColor = color(251, 251, 30);
                break;
            case 3:
                nodeColor = color(179, 1, 1);
                break;
            case 4:
                nodeColor = color(72, 215, 254);
                break;
            default:
                nodeColor = 0xff000000;
                break;
        }
        wires = new ArrayList<Wire>();
    }
    
    public boolean containsPoint(int x, int y, int tronicX, int tronicY){
        return x >= (this.x + tronicX) - 5 && x <= (this.x + WIDTH + tronicX) + 5 && y >= (this.y + tronicY) - 5 && y <= (this.y + HEIGHT + tronicY) + 5;
    }
    
    public void render(int mouseX, int mouseY, int screenX, int screenY, int tronicX, int tronicY, float zoom, boolean highlight){
        if(highlight && containsPoint(screenX + (int)(mouseX / zoom), screenY + (int)(mouseY / zoom), tronicX, tronicY)){
            fill(0xffD0D0D0);
        }else{
            fill(nodeColor);
        }
        //rect(tronicX + x,tronicY + y,tronicX + x + WIDTH, tronicY + y + HEIGHT);
        noStroke();
        rect(-screenX + tronicX + x,-screenY + tronicY + y, WIDTH, HEIGHT);
    }
    
    public Tronic getParent(){
        return parent;
    }
    
    public int getX(){
        return x;
    }
    
    public int getY(){
        return y;
    }
    
    public int getDirX(){
        return dirX;
    }
    
    public int getDirY(){
        return dirY;
    }
    
    public int getNodeColor(){
        return nodeColor;
    }
    
    public int getType(){
        return type;
    }
    
    public void addWire(Wire wire){
        wires.add(wire);
    }
    
    public Wire getWire(int index){
        return wires.get(index);
    }
    
    public void deleteWire(Wire wire){
        wires.remove(wire);
    }
    
    public int getNumWires(){
        return wires.size();
    }
}
class OperatorTronic extends Tronic implements InFlow{
    PImage sprite;
    int type;
    InFlow nextTronic;
    
    Node inNode;
    Node outNode;
    Node aNode;
    Node bNode;
    Node dataNode;
    
    public OperatorTronic(int x, int y, String name){
        this(0, x, y, name);
    }
    
    public OperatorTronic(int type, int x, int y, String name){
        super(x, y, 48, 48, name);
        this.type = type;
        switch(type){
            case 0:
                sprite = loadImage("assets/add.png");
                break;
            case 1:
                sprite = loadImage("assets/subtract.png");
                break;
            case 2:
                sprite = loadImage("assets/multi.png");
                break;
            case 3:
                sprite = loadImage("assets/divide.png");
                break;
            case 4:
                sprite = loadImage("assets/and.png");
                break;
            case 5:
                sprite = loadImage("assets/random.png");
                break;
            case 6:
                sprite = loadImage("assets/modulo.png");
                break;
            default:
                sprite = loadImage("assets/add.png");
                break;
        }
        inNode = new Node(this, 2, -6, 21, -1, 0);
        outNode = new Node(this, 3, 48, 21, 1, 0);
        aNode = new Node(this, 1, 12, -6, 0, -1);
        bNode = new Node(this, 1, 30, -6, 0, -1);
        dataNode = new Node(this, 0, 21, 48, 0, 1);
    }
    
    public Node getFlow(FlowDetails flow){
        String a;
        double numA;
        String b;
        double numB;
        if(dataNode.getNumWires() > 0){
            a = flow.getData(aNode);
            if(a.equals("")){
                numA = 0;
            }else{
                try{
                    numA = Double.valueOf(a);
                }catch(NumberFormatException e){
                    numA = 0;
                }
            }
            b = flow.getData(bNode);
            if(b.equals("")){
                numB = 0;
            }else{
                try{
                    numB = Double.valueOf(b);
                }catch(NumberFormatException e){
                    numB = 0;
                }
            }
            String result;
            switch(type){
                case 0:
                    result = Double.toString(numA + numB);
                    break;
                case 1:
                    result = Double.toString(numA - numB);
                    break;
                case 2:
                    result = Double.toString(numA * numB);
                    break;
                case 3:
                    if(numB != 0){
                        result = Double.toString(numA / numB);
                    }else{
                        println("Attempted to divide by 0! Ending flow.");
                        return null;
                    }
                    break;
                case 4:
                    result = a + b;
                    break;
                case 5:
                    if(a.equals("") && b.equals("")){
                        result = Double.toString(random(1.0f));
                    }else{
                        result = Double.toString(random((float) numA,(float)  numB));
                    }
                    break;
                case 6:
                    result = Double.toString(numA % numB);
                    break;
                default:
                    result = a + b;
                    break;
            }
            flow.setData(dataNode, result);
        }
        return outNode;
    }
    
    public int getType(){
        return type;
    }
    
    public void renderTronic(int screenX, int screenY){
        image(sprite, (getX() - screenX) * 2, (getY() - screenY) * 2);
    }
    
    public void renderNodes(int mouseX, int mouseY, int screenX, int screenY, float zoom, boolean highlight){
        inNode.render(mouseX, mouseY, screenX, screenY, getX(), getY(), zoom, highlight);
        outNode.render(mouseX, mouseY, screenX, screenY, getX(), getY(), zoom, highlight);
        aNode.render(mouseX, mouseY, screenX, screenY, getX(), getY(), zoom, highlight);
        bNode.render(mouseX, mouseY, screenX, screenY, getX(), getY(), zoom, highlight);
        dataNode.render(mouseX, mouseY, screenX, screenY, getX(), getY(), zoom, highlight);
    }
    
    public Node[] getNodes(){
        return new Node[]{inNode, outNode, aNode, bNode, dataNode};
    }
}
interface QueuedEvent{
    public double getDelay();
    public void invoke();
}
class QueuedWrapper{
    double time;
    QueuedEvent evt;
    
    public QueuedWrapper(QueuedEvent evt){
        this.evt = evt;
        this.time = 0;
    }
    
    public boolean tick(double dt){
        time += dt;
        if(time >= evt.getDelay()){
            evt.invoke();
            return true;
        }
        return false;
    }
}


class SmallTextEntry extends JFrame{
    JTextField textArea;
    JPopupMenu popup;
    java.awt.Font psn;
    SmallTextEntryEvent textEvent;
    
    public SmallTextEntry(String def, SmallTextEntryEvent event){
        this(def, "Save", event);
    }
    
    public SmallTextEntry(String def, String action, SmallTextEntryEvent event){
        super();
        this.textEvent = event;
        setAlwaysOnTop(true);
        setResizable(false);
        try{
            psn = (java.awt.Font.createFont(java.awt.Font.TRUETYPE_FONT, new java.io.File(dataPath("neverfont.ttf")))).deriveFont(8f);
        }catch(Exception e){
            psn = new java.awt.Font("Consolas", java.awt.Font.PLAIN, 12);
            e.printStackTrace();
        }
        try{
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }catch(Exception e){
            //whatever jeez....
        }
        textArea = new JTextField(def);
        textArea.setFont(psn);
        textArea.setEditable(true);
        textArea.setEnabled(true);
        textArea.setBackground(java.awt.Color.BLACK);
        textArea.setForeground(java.awt.Color.GREEN);
        textArea.setCaretColor(java.awt.Color.GREEN);
        
        popup = new JPopupMenu();
        JMenuItem cutItem = new JMenuItem("Cut");
        cutItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                textArea.cut();
            }
        });
        JMenuItem copyItem = new JMenuItem("Copy");
        copyItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                textArea.copy();
            }
        });
        JMenuItem pasteItem = new JMenuItem("Paste");
        pasteItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                textArea.paste();
            }
        });
        JMenuItem selectItem = new JMenuItem("Select All");
        selectItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                textArea.selectAll();
            }
        });
        popup.add(cutItem);
        popup.add(copyItem);
        popup.add(pasteItem);
        popup.addSeparator();
        popup.add(selectItem);
        
        textArea.addMouseListener(new java.awt.event.MouseListener() {
            public void mouseReleased(java.awt.event.MouseEvent arg0) {
                if(arg0.isPopupTrigger()){
                    popup.show(textArea, arg0.getX(), arg0.getY());
                }
            }
            public void mousePressed(java.awt.event.MouseEvent arg0) {}
            public void mouseExited(java.awt.event.MouseEvent arg0) {}
            public void mouseEntered(java.awt.event.MouseEvent arg0) {}
            public void mouseClicked(java.awt.event.MouseEvent arg0) {}
        });
        JButton cancelData = new JButton("Cancel");
        JButton saveData = new JButton(action);
        JButton clearData = new JButton("Clear");
        
        cancelData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                textEvent.canceled();
                setVisible(false);
                dispose();
            }
        });
        saveData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                textEvent.saved(textArea.getText());
                setVisible(false);
                dispose();
            }
        });
        clearData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                textArea.setText("");
            }
        });
        
        addWindowListener(new java.awt.event.WindowListener() {
           public void windowOpened(java.awt.event.WindowEvent e) {}
           public void windowIconified(java.awt.event.WindowEvent e) {}
           public void windowDeiconified(java.awt.event.WindowEvent e) {}
           public void windowDeactivated(java.awt.event.WindowEvent e) {}
           public void windowClosing(java.awt.event.WindowEvent e) {
               textEvent.canceled();
               setVisible(false);
               dispose();
           }
           public void windowClosed(java.awt.event.WindowEvent e) {}
           public void windowActivated(java.awt.event.WindowEvent e) {}
        });
        
        GroupLayout layout = new GroupLayout(getContentPane());
        layout.setHorizontalGroup(
            layout.createParallelGroup()
            .addGroup(layout.createSequentialGroup()
                .addComponent(cancelData)
                .addComponent(saveData)
                .addComponent(clearData)
                )
            .addComponent(textArea)
        );
        layout.setVerticalGroup(
            layout.createSequentialGroup()
            .addGroup(layout.createParallelGroup()
                .addComponent(cancelData)
                .addComponent(saveData)
                .addComponent(clearData)
            )
            .addComponent(textArea)
        );
        getContentPane().setLayout(layout);
        
        pack();
        setMaximumSize(new java.awt.Dimension(300, 20));
    }
    
    public void showWindow(){
        setVisible(true);
        toFront();
        textArea.grabFocus();
    }
}
interface SmallTextEntryEvent{
    public void canceled();
    public void saved(String contents);
}
public abstract class Tronic{
    int x;
    int y;
    final int WIDTH;
    final int HEIGHT;
    String name;
    boolean enabled;
    
    public Tronic(int x, int y, int w, int h, String name){
        this.x = x;
        this.y = y;
        this.WIDTH = w;
        this.HEIGHT = h;
        this.name = name;
        this.enabled = true;
    }
    
    public int getX(){
        return x;
    }
    
    public int getY(){
        return y;
    }
    
    public int getWidth(){
        return WIDTH;
    }
    
    public int getHeight(){
        return HEIGHT;
    }
    
    public void moveTronic(int x, int y){
        this.x = x;
        this.y = y;
    }
    
    public boolean containsPoint(int px, int py){
        return px >= x && px <= x + WIDTH && py >= y && py <= y + HEIGHT;
    }
    
    public void setEnabled(){
        enabled = true;
    }
    
    public void setDisabled(){
        enabled = false;
    }
    
    public boolean isEnabled(){
        return enabled;
    }
    
    public String toString(){
        return name;
    }
    
    public void setName(String name){
        this.name = name;
    }
    
    public abstract void renderTronic(int screenX, int screenY);
    public abstract void renderNodes(int mouseX, int mouseY, int screenX, int screenY, float zoom, boolean highlight);
    public abstract Node[] getNodes();
}
class Wire{
    Node firstNode;
    Tronic firstTronic;
    Node lastNode;
    Tronic lastTronic;
    int wireColor;
    int pending;
    
    public Wire(Node firstNode, Node lastNode, int wireColor){
        this.firstNode = firstNode;
        this.firstTronic = firstNode.getParent();
        this.lastNode = lastNode;
        this.lastTronic = lastNode.getParent();
        this.wireColor = wireColor;
    }
    
    public void render(int screenX, int screenY){
        render(screenX, screenY, wireColor);
    }
    
    public void render(int screenX, int screenY, int thisColor){
        stroke(thisColor);
        strokeCap(SQUARE);
        noFill();
        int tronicX1 = firstTronic.getX() - screenX;
        int tronicY1 = firstTronic.getY() - screenY;
        int pointX1 = firstNode.getX() + 3;
        int pointY1 = firstNode.getY() + 3;
        int tronicX2 = lastTronic.getX() - screenX;
        int tronicY2 = lastTronic.getY() - screenY;
        int pointX2 = lastNode.getX() + 3;
        int pointY2 = lastNode.getY() + 3;
        int distance = (int) sqrt(pow((tronicX1 + pointX1) - (tronicX2 + pointX2),2) + pow((tronicY1 + pointY1) - (tronicY2 + pointY2),2)) / 2;
        int dirX1 = firstNode.getDirX() * distance;
        int dirY1 = firstNode.getDirY() * distance;
        int dirX2 = lastNode.getDirX() * distance;
        int dirY2 = lastNode.getDirY() * distance;
        bezier(tronicX1 + pointX1, tronicY1 + pointY1, tronicX1 + pointX1 + dirX1, tronicY1 + pointY1 + dirY1, tronicX2 + pointX2 + dirX2, tronicY2 + pointY2 + dirY2, tronicX2 + pointX2, tronicY2 + pointY2);
    }
    
    public Node getOtherNode(Node thisNode){
        if(thisNode.equals(firstNode)){
            return lastNode;
        }else if(thisNode.equals(lastNode)){
            return firstNode;
        }
        return null;
    }
    
    public void addPending(){
        pending++;
    }
    
    public void subPending(){
        pending--;
    }
    
    public boolean getActivated(){
        return pending > 0;
    }
    
    public int getWireColor(){
        return wireColor;
    }
    
    public void deleteWire(){
        firstNode.deleteWire(this);
        lastNode.deleteWire(this);
    }
}
    public void settings() {  size(800,600,P2D); }
    static public void main(String[] passedArgs) {
        String[] appletArgs = new String[] { "minitrons_remake" };
        if (passedArgs != null) {
          PApplet.main(concat(appletArgs, passedArgs));
        } else {
          PApplet.main(appletArgs);
        }
    }
}
